import java.util.ArrayList;
public class Res {
        ArrayList<User> Res =new ArrayList<>();

        public void Reg(String name, int pass)
        {
            User new_user= new User();
            new_user.setpassword(pass);
            new_user.setname(name);
            Res.add(new_user);
            System.out.println(name+"\n"+pass);
        }
        public void reg(User name)
        {


            String pass="AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuWwXxYyZz1234567890!@#$%^&*_-+=':;";
            for (int i = 0; i < pass.length(); i++){
                pass+=pass.charAt((int) Math.random()* (((pass.length() - 0)) + 0));
            }

            User new_user= new User();
            new_user.setpassword(pass);
            new_user.setname(name);
            Res.add(new_user);

        }
        public void del(String name,String pass){

            //Res.add(res);
            int d;
            for (d=0;d<Res.size();d++);
            if (Res.get(d).getName().equals(name)&& Res.get(d).getPassword().equals(pass));
            {Res.remove(d);}
        }
    public void add_User(User new_User) {
        if (this.reg (new_User)) {
            this.Res.add(new_User);
        } else {
            System.out.println("Ошибка");
        }

    }
}