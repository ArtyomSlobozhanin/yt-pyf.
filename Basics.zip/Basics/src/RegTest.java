import org.junit.jupiter.api.Assertions;

public class RegTest {

    private Object User;

    @org.junit.jupiter.api.Test
    public void reg()
    {
     Res Res1=new Res();

        User user1=new User();
        user1.setname("Имя");
        Res1.add_User(user1);

        Assertions.assertEquals(1,Res1.Res.get(0));
    }

    @org.junit.jupiter.api.Test
    void testReg()
    {
        Res Res1=new Res();
        User user1=new User();
        user1.setname("Имя");

        User user2=new User();
        user2.setname("Имя");

        Res1.add_User(user1);


        Assertions.assertEquals(false,Res1);
    }

    @org.junit.jupiter.api.Test
    void del()
    {
        Res Res1=new Res();

        User user1=new User();
        user1.setpassword(1);
        Res1.add_User(user1);

        Assertions.assertEquals(1,Res1.Res.get(0));
    }
    @org.junit.jupiter.api.Test
    public void pas()
    {
        Res Res1=new Res();
        User user1=new User();
        user1.setpassword(1);

        User user2=new User();
        user2.setpassword(1);

        Res1.add_User(user1);


        Assertions.assertEquals(false,Res1);
    }
}
