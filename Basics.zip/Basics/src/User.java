public class User {
        private String name;
        private String password;

        public String getName () {
        return this.name;
    }
        public String getPassword () {
        return this.password;
    }
        public void setname (String set_name){
        this.name = name;
    }
        public void setpassword (int set_password){
        this.password = set_password;
    }
}
